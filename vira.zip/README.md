# Faza Api
<p align="center">
<a href="#"><img title="Faza-Api" src="https://img.shields.io/badge/Rest Api Free-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/xdlyy404"><img title="Author" src="https://img.shields.io/badge/AUTHOR-FADLY%20ID-orange.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/xdlyy404/followers"><img title="Followers" src="https://img.shields.io/github/followers/xdlyy404?color=blue&style=flat-square"></a>
<a href="https://github.com/xdlyy404/RESTAPI/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/xdlyy404/RESTAPI?color=red&style=flat-square"></a>
<a href="https://github.com/xdlyy404/RESTAPI/network/members"><img title="Forks" src="https://img.shields.io/github/forks/xdlyy404/RESTAPI?color=red&style=flat-square"></a>
<a href="https://github.com/xdlyy404/RESTAPI/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/xdlyy404/RESTAPI?label=Watchers&color=blue&style=flat-square"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fxdlyy404%2FRESTAPI&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2300FF6D&title=hits&edge_flat=false"/></a>
</p>
